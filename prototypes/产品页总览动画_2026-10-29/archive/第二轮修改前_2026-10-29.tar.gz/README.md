# 沐仞产品页 · 总览动画

直接打开 `ov-anim.html`。无需构建、服务器或运行时依赖。左侧没有文字；右侧四行 HTML 通过 `ovlayer` 事件同步。

## 嵌入

将 `ov-anim.css`、`ov-anim.js`、`layers/` 和原始 `engineering-stack_2026-10-14.png` 一起复制到网站资源目录，例如 `/assets/overview/`：

```html
<link rel="stylesheet" href="/assets/overview/ov-anim.css">
<div class="ov-anim" data-layer="0" role="img"
     aria-label="接入、调度、计算、电力四层基础设施">
  <img class="ov-original"
       src="/assets/overview/engineering-stack_2026-10-14.png"
       width="1254" height="1254" alt="" decoding="async">
</div>
<script src="/assets/overview/ov-anim.js" defer></script>
```

容器宽度由页面布局决定，组件 `width:100%`、`max-width:620px`、正方形比例；SVG `viewBox="0 0 1254 1254"`。设计范围 280–620px。组件样式均限定在 `.ov-anim` 下；演示页排版样式只在 HTML 内，不需复制。

默认分层资源相对于 **JS 文件所在目录** 寻找 `layers/layer-0.webp` 至 `layer-3.webp`。如需分开放置，在根元素添加 `data-assets="/your/path/layers/"`；该自定义路径相对于页面 URL 解析。原图 `src` 相对于页面 URL 解析。

## 事件接口

```js
const root = document.querySelector('.ov-anim');
root.addEventListener('ovlayer', ({ detail: { layer } }) => {
  document.querySelectorAll('.overview-copy > li').forEach((row, i) => {
    row.classList.toggle('is-active', i === layer);
  });
});
// 随时读取当前层：Number(root.dataset.layer)
```

层号：`0` 接入 / 绿色 Token 交易平台；`1` 调度 / 算电协同世界模型基座；`2` 计算 / FPTM 系列 Token 一体机；`3` 电力 / 光伏、风电、水电场站。

图片加载成功后首次发出层 0 事件；以后每 2 秒切换一次，8 秒一轮。事件从根元素发出并冒泡，`detail` 为 `{layer: 0..3}`。先注册监听器，或使用 `dataset.layer` 同步已经初始化的组件。

鼠标进入某层立即选中该层，暂停轮播、浮动和光点；移开后从该层重新计时 2 秒。触屏不锁定悬停。页面进入后台时暂停，返回后继续。支持同页多个实例。

动态插入根元素后调用 `window.OvAnimation.init(root)`；销毁时调用 `root.ovAnimation.destroy()`，会清理计时器、全局监听器和 SVG，并恢复原图。重复初始化不生成重复 SVG。

## 动画与素材

- 7.6 秒呼吸周期，四层错开 1.9 秒。位移为画布高度的 ±0.24%，在 620px 宽时约 ±1.49px。
- 蓝色 `#2F63B8` 沿可见竖管向下，浅紫 `#D6CBDD` 向上；SVG 分段避开设备和接线盒遮挡。管线光点与所属图片共用同一个浮动组。
- 淡蓝平台边缘光晕与前缘描边同步点亮，650ms 渐变。
- `prefers-reduced-motion: reduce` 时隐藏整个 SVG、停止计时，只显示原始 PNG。无 JS 或任意分层加载失败也保留原图。
- 不新增文字或虚构设施；保留原图颜色。动画叠加只使用指定色板；演示背景为 `#F7F7F5`。
- 四张新增 WebP 合计 **595,426 字节**，低于严格的 600,000 字节上限；原有 PNG 仍用于静态回退，不计入新增图片。无额外 PNG 备份或截图随组件部署。
- 四张图保持完整 1254×1254 透明画布，互斥多边形分区；连接管归上层。不补画原图被遮挡的区域，因此保持很小的浮动幅度。
- WebP 使用近无损 RGB 预处理，再恢复源图 alpha 并无损编码。复合透明通道与原图逐像素一致；可见 RGB 单通道最大误差 4/255，平均绝对误差 0.805811/255。**不是 RGB 位级无损**，没有缩放或几何位移。

## 验证与复现（2026-10-29）

`layers/manifest.json` 记录源图 SHA-256、原始修改时间、分层边界、字节数与压缩误差。分层导出：

```sh
# 开发工具：Python + Pillow + NumPy，以及 libwebp 的 cwebp；网站不需要这些依赖。
python3 build_layers_2026-10-29.py
node --check ov-anim.js
# 安装 jsdom 后运行；也可通过 NODE_PATH 指定现有 jsdom 安装路径。
node verify_ov_2026-10-29.cjs
```

已执行并通过：图片字节上限、alpha 逐像素重建、RGB 误差检查、分层及复合图静态目视检查、管线坐标叠加检查、JS 语法、DOM 初始化、层事件顺序、悬停暂停/恢复、减少动态模式停止计时、后台暂停、销毁清理。DOM 检查结果见 `verification_2026-10-29.json`；其中图片加载完成信号及计时器由测试环境提供，不能替代浏览器验收。

**浏览器验收未完成**：本次环境中系统 Chrome 和官方独立 headless shell 均因 macOS 沙箱 `bootstrap_check_in ... Permission denied (1100)` 无法启动；CUA 浏览器 host 也不可用。静态图检查是 PIL 图像复合检查，不是网页截图。尚未确认实际浏览器中 280/620px 布局、CSS 动画、SVG 发光滤镜和系统减少动态偏好的最终渲染表现。后续在允许启动浏览器的环境打开演示页，检查上述尺寸、四层悬停以及减少动态模式即可。

参考页：https://www.infinigence-ai.com/agentic-infra/llm-inference.html 。已读取页面内容；首屏动态截图同样受浏览器限制，节奏依据任务书指定的安静循环效果实现。

当前目录原本不是 Git 仓库；尝试 `git init` 被沙箱拒绝，因此未能执行提交。所有输入文件均保留，只新增上述组件及验证文件。
